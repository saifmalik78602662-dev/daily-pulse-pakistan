// ---------------------------------------------------------------------
// Shared server-side HTML templating.
//
// Pages built with these helpers are rendered to full HTML on the
// server, with real article text already in the markup — so search
// engines (and users with JavaScript disabled) see the actual content,
// not an empty shell waiting on a fetch() call.
// ---------------------------------------------------------------------

const SITE_NAME = 'Daily Pulse Pakistan';
const CONTACT_EMAIL = process.env.CONTACT_EMAIL || 'saifmalik78602662@gmail.com';

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function fmtDate(iso) {
  return new Date(iso).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}

function fmtDateShort(iso) {
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function timeAgo(iso) {
  const hrs = Math.floor((Date.now() - new Date(iso).getTime()) / 3600000);
  if (hrs < 1) return 'Just now';
  if (hrs < 24) return hrs + 'h ago';
  return Math.floor(hrs / 24) + 'd ago';
}

function baseUrl(req) {
  return `${req.protocol}://${req.get('host')}`;
}

// Shared <head> + header/ticker markup, and shared footer — identical
// across every page so the design/structure stays exactly as before.
function headHtml({ title, description, canonical, ogType = 'website' }) {
  return `<!DOCTYPE html>
<html lang="ur" dir="ltr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(title)}</title>
<meta name="description" content="${escapeHtml(description)}">
<link rel="canonical" href="${escapeHtml(canonical)}">
<meta property="og:site_name" content="${SITE_NAME}">
<meta property="og:type" content="${ogType}">
<meta property="og:title" content="${escapeHtml(title)}">
<meta property="og:description" content="${escapeHtml(description)}">
<meta property="og:url" content="${escapeHtml(canonical)}">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="${escapeHtml(title)}">
<meta name="twitter:description" content="${escapeHtml(description)}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,700;0,900;1,600&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/styles.css">
</head>
<body>`;
}

function tickerHtml() {
  return `<div class="ticker">
  <div class="tag">لائیو</div>
  <div class="ticker-track">
    <span>پارلیمنٹ میں نئے معاشی بل پر بحث جاری، حزب اختلاف کا احتجاج</span>
    <span>سٹاک مارکیٹ میں مسلسل تیسرے دن تیزی، انڈیکس نئی بلندی پر</span>
    <span>موسمیاتی محکمے کی اگلے ہفتے شدید بارشوں کی پیش گوئی</span>
    <span>قومی کرکٹ ٹیم کا نیا شیڈول جاری، پہلا میچ اگلے ماہ</span>
    <span>ٹیکنالوجی سیکٹر میں نئی سرمایہ کاری، ہزاروں نوکریوں کا امکان</span>
  </div>
</div>`;
}

function headerHtml(active) {
  const navClass = (name) => (active === name ? ' class="active"' : '');
  return `<header>
  <div class="masthead wrap">
    <a href="/" class="logo">Daily <span>Pulse</span> Pakistan</a>
    <nav id="mainnav">
      <a href="/"${navClass('home')}>Home</a>
      <a href="/#news"${navClass('news')}>News</a>
      <a href="/articles.html"${navClass('articles')}>Articles</a>
      <a href="/#about"${navClass('about')}>About</a>
      <a href="/#contact"${navClass('contact')}>Contact</a>
      <a href="/admin.html" class="admin-btn">Admin</a>
    </nav>
    <div class="datebar mono">${escapeHtml(new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }))}</div>
  </div>
  <div class="navwrap">
    <div class="subnav wrap">
      <a href="/articles.html?category=Pakistan">Pakistan</a>
      <a href="/articles.html?category=World">World</a>
      <a href="/articles.html?category=Business">Business</a>
      <a href="/articles.html?category=Technology">Technology</a>
      <a href="/articles.html?category=Sports">Sports</a>
      <a href="/articles.html?category=Opinion">Opinion</a>
      <a href="/articles.html?category=Weather">Weather</a>
    </div>
  </div>
</header>`;
}

function footerHtml() {
  return `<footer>
  <div class="wrap footer-grid">
    <a href="/" class="footer-logo">Daily <span>Pulse</span> Pakistan</a>
    <div class="footer-links">
      <a href="/#news">News</a>
      <a href="/articles.html">Articles</a>
      <a href="/#about">About</a>
      <a href="/#contact">Contact</a>
      <a href="/privacy-policy.html">Privacy Policy</a>
      <a href="/terms.html">Terms &amp; Conditions</a>
      <a href="/disclaimer.html">Disclaimer</a>
    </div>
    <div class="copyright">© ${new Date().getFullYear()} ${SITE_NAME}. All rights reserved.</div>
  </div>
</footer>`;
}

function page({ title, description, canonical, ogType, active, bodyHtml, extraScripts = '' }) {
  return `${headHtml({ title, description, canonical, ogType })}
${tickerHtml()}
${headerHtml(active)}
${bodyHtml}
${footerHtml()}
${extraScripts}
</body>
</html>`;
}

// --- Article card fragments, reused by the homepage and the articles page ---

function heroFragment(article) {
  if (!article) {
    return `<div class="eyebrow">Breaking — Top Story</div><h1>No articles published yet</h1><p>Check back soon, or log in to the admin dashboard to publish the first story.</p>`;
  }
  return `<div class="eyebrow">Breaking — Top Story</div>
<h1><a href="/article/${escapeHtml(article.slug)}" style="color:inherit;">${escapeHtml(article.title)}</a></h1>
<p>${escapeHtml(article.excerpt)}</p>
<div class="byline">By ${escapeHtml(article.author || 'Staff Reporter')} · ${fmtDateShort(article.created_at)}</div>`;
}

function sideStoryFragment(a) {
  return `<div class="side-story">
    <div class="cat">${escapeHtml(a.category)}</div>
    <h3><a href="/article/${escapeHtml(a.slug)}">${escapeHtml(a.title)}</a></h3>
    <div class="meta">${escapeHtml(a.author || 'Staff')} · ${timeAgo(a.created_at)}</div>
  </div>`;
}

function cardFragment(a) {
  return `<article class="card">
    <div class="cat">${escapeHtml(a.category)}</div>
    <h3><a href="/article/${escapeHtml(a.slug)}">${escapeHtml(a.title)}</a></h3>
    <p>${escapeHtml(a.excerpt)}</p>
    <div class="meta"><span>${escapeHtml(a.author || 'Staff')}</span><span>${timeAgo(a.created_at)}</span></div>
  </article>`;
}

module.exports = {
  SITE_NAME,
  CONTACT_EMAIL,
  escapeHtml,
  fmtDate,
  fmtDateShort,
  timeAgo,
  baseUrl,
  page,
  heroFragment,
  sideStoryFragment,
  cardFragment,
};
